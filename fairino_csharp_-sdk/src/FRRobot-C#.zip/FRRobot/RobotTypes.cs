﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
//using System.Threading.Tasks;

namespace fairino
{
    /**
    * @brief 关节位置数据类型
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct JointPos
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] jPos;   /* 六个关节位置，单位deg */

        public JointPos(double[] pos)
        {
            jPos = pos;
        }

        public JointPos(double j1, double j2, double j3, double j4, double j5, double j6)
        {
            jPos = new double[6] { j1, j2, j3, j4, j5, j6};
        }
    }

    /**
    * @brief 笛卡尔空间位置数据类型
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct DescTran
    {
        public double x;    /* x轴坐标，单位mm  */
        public double y;    /* y轴坐标，单位mm  */
        public double z;    /* z轴坐标，单位mm  */
        public DescTran(double posX, double posY, double posZ)
        {
            x = posX; 
            y = posY; 
            z = posZ;
        }
    }

    /**
    * @brief 欧拉角姿态数据类型
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct Rpy
    {
        public double rx;   /* 绕固定轴X旋转角度，单位：deg  */
        public double ry;   /* 绕固定轴Y旋转角度，单位：deg  */
        public double rz;   /* 绕固定轴Z旋转角度，单位：deg  */
        public Rpy(double rotateX, double rotateY, double rotateZ)
        {
            rx = rotateX;
            ry = rotateY;
            rz = rotateZ;
        }
    }

    /**
    *@brief 笛卡尔空间位姿类型
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct DescPose
    {
        public DescTran tran;      /* 笛卡尔空间位置  */
        public Rpy rpy;			/* 笛卡尔空间姿态  */
        public DescPose(DescTran descTran, Rpy rotateRpy)
        {
            tran = descTran;
            rpy = rotateRpy;
        }

        public DescPose(double tranX, double tranY, double tranZ, double rX, double ry, double rz)
        {
            tran.x = tranX;
            tran.y = tranY;
            tran.z = tranZ;
            rpy.rx = rX;
            rpy.ry = ry;
            rpy.rz = rz;
        }
    }

    /**
    * @brief 扩展轴位置数据类型
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct ExaxisPos
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public double[] ePos;   /* 四个扩展轴位置，单位mm */
        public ExaxisPos(double[] exaxisPos)
        { 
            ePos = exaxisPos;
        }

        public ExaxisPos(double x, double y, double z, double a)
        {
            ePos = new double[4] { x, y, z, a};
        }
    }

    /**
    * @brief 力传感器的受力分量和力矩分量
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct ForceTorque
    {
        public double fx;  /* 沿x轴受力分量，单位N  */
        public double fy;  /* 沿y轴受力分量，单位N  */
        public double fz;  /* 沿z轴受力分量，单位N  */
        public double tx;  /* 绕x轴力矩分量，单位Nm */
        public double ty;  /* 绕y轴力矩分量，单位Nm */
        public double tz;  /* 绕z轴力矩分量，单位Nm */
        public ForceTorque(double fX, double fY, double fZ, double tX, double tY, double tZ)
        {
            fx = fX; 
            fy = fY; 
            fz = fZ; 
            tx = tX; 
            ty = tY; 
            tz = tZ;
        }
    }

    /**
    * @brief  螺旋参数数据类型
    */
    [StructLayout(LayoutKind.Sequential)]
    public struct SpiralParam
    {
        public int circle_num;           /* 螺旋圈数  */
        public float circle_angle;         /* 螺旋倾角  */
        public float rad_init;             /* 螺旋初始半径，单位mm  */
        public float rad_add;              /* 半径增量  */
        public float rotaxis_add;          /* 转轴方向增量  */
        public uint rot_direction;  /* 旋转方向，0-顺时针，1-逆时针  */
        public SpiralParam(int circleNum, float circleAngle, float radInit, float radAdd, float rotaxisAdd, uint rotDirection)
        {
            circle_num = circleNum; 
            circle_angle = circleAngle;
            rad_init = radInit;
            rad_add = radAdd;
            rotaxis_add = rotaxisAdd;
            rot_direction = rotDirection;
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct ROBOT_AUX_STATE
    {
        public byte servoId;           //伺服驱动器ID号
        public int servoErrCode;       //伺服驱动器故障码
        public int servoState;         //伺服驱动器状态
        public double servoPos;        //伺服当前位置
        public float servoVel;         //伺服当前速度
        public float servoTorque;      //伺服当前转矩    25
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct EXT_AXIS_STATUS
    {
        public double pos;        //扩展轴位置
        public double vel;        //扩展轴速度
        public int errorCode;     //扩展轴故障码
        public byte ready;        //伺服准备好
        public byte inPos;        //伺服到位
        public byte alarm;        //伺服报警
        public byte flerr;        //跟随误差
        public byte nlimit;       //到负限位
        public byte pLimit;       //到正限位
        public byte mdbsOffLine;  //驱动器485总线掉线
        public byte mdbsTimeout;  //控制卡与控制箱485通信超时
        public byte homingStatus; //扩展轴回零状态
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct ROBOT_STATE_PKG
    {
        public UInt16 frame_head;           //帧头 0x5A5A
        public byte frame_cnt;              //帧计数
        public UInt16 data_len;             //数据长度  5
        public byte program_state;          //程序运行状态，1-停止；2-运行；3-暂停
        public byte robot_state;            //机器人运动状态，1-停止；2-运行；3-暂停；4-拖动  7
        public int main_code;               //主故障码
        public int sub_code;                //子故障码
        public byte robot_mode;             //机器人模式，0-自动模式；1-手动模式 16

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] jt_cur_pos;                             //关节当前位置
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] tl_cur_pos;                             //工具当前位姿
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] flange_cur_pos;                         //末端法兰当前位姿
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] actual_qd;                              //机器人当前关节速度
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] actual_qdd;                             //机器人当前关节加速度  16 + 8 * 6 * 5 = 256
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public double[] target_TCP_CmpSpeed;                    //机器人TCP合成指令速度                         //256 + 8* 2 = 272
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] target_TCP_Speed;                       //机器人TCP指令速度                        //272 + 8 * 6 = 320 
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public double[] actual_TCP_CmpSpeed;                    //机器人TCP合成实际速度                        //320 + 16 = 336
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] actual_TCP_Speed;                       //机器人TCP实际速度                      //336 + 8 * 6 = 384
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] jt_cur_tor;                             //当前扭矩         //384 + 8 * 6 = 432 
        public int tool;                        //工具号
        public int user;                        //工件号
        public byte cl_dgt_output_h;            //数字输出15-8
        public byte cl_dgt_output_l;            //数字输出7-0
        public byte tl_dgt_output_l;            //工具数字输出7-0(仅bit0-bit1有效)
        public byte cl_dgt_input_h;             //数字输入15-8
        public byte cl_dgt_input_l;             //数字输入7-0
        public byte tl_dgt_input_l;             //工具数字输入7-0(仅bit0-bit1有效)                    // + 14 = 446
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public UInt16[] cl_analog_input;        //控制箱模拟量输入
        public UInt16 tl_anglog_input;          //工具模拟量输入                              // + 6 = 452
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] ft_sensor_raw_data;     //力/扭矩传感器原始数据
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public double[] ft_sensor_data;         //力/扭矩传感器数据                           // + 8 * 12 = 548
        public byte ft_sensor_active;           //力/扭矩传感器激活状态， 0-复位，1-激活
        public byte EmergencyStop;              //急停标志
        public int motion_done;                 //到位信号
        public byte gripper_motiondone;         //夹爪运动完成信号
        public int mc_queue_len;                //运动队列长度
        public byte collisionState;             //碰撞检测，1-碰撞；0-无碰撞
        public int trajectory_pnum;             //轨迹点编号
        public byte safety_stop0_state;  /* 安全停止信号SI0 */
        public byte safety_stop1_state;  /* 安全停止信号SI1 */
        public byte gripper_fault_id;    /* 错误夹爪号 */               // + 19 = 567
        public UInt16 gripper_fault;     /* 夹爪故障 */
        public UInt16 gripper_active;    /* 夹爪激活状态 */
        public byte gripper_position;    /* 夹爪位置 */
        public byte gripper_speed;       /* 夹爪速度 */
        public byte gripper_current;     /* 夹爪电流 */
        public int gripper_tmp;          /* 夹爪温度 */
        public int gripper_voltage;      /* 夹爪电压 */                 // + 15 = 582
        public ROBOT_AUX_STATE auxState; /* 485扩展轴状态 */            // + 25 = 607
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public EXT_AXIS_STATUS[] extAxisStatus;  /* UDP扩展轴状态 */
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public UInt16[] extDIState;        //扩展DI输入
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public UInt16[] extDOState;        //扩展DO输出
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public UInt16[] extAIState;        //扩展AI输入
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public UInt16[] extAOState;        //扩展AO输出
        public int rbtEnableState;       //机器人使能状态--robot enable state
        public UInt16 check_sum;         /* 和校验 */                  // + 2 = 609
    }

    enum RobotError
    {
        ERR_UPLOAD_FILE_NOT_FOUND = -7,   /* 上传文件不存在 */
        ERR_SAVE_FILE_PATH_NOT_FOUND = -6,/* 保存文件路径不存在 */
        ERR_NOT_FOUND_LUA_FILE = -5,      /* lua文件不存在 */
        ERR_RPC_ERROR = -4,
        ERR_SOCKET_COM_FAILED = -2,
        ERR_OTHER = -1,
        ERR_SUCCESS = 0,
        ERR_PARAM_NUM = 3,
        ERR_PARAM_VALUE = 4,
        ERR_TPD_FILE_OPEN_FAILED = 8,
        ERR_EXECUTION_FAILED = 14,
        ERR_PROGRAM_IS_RUNNING = 18,
        ERR_COMPUTE_FAILED = 25,
        ERR_INVERSE_KINEMATICS_COMPUTE_FAILED = 28,
        ERR_SERVOJ_JOINT_OVERRUN = 29,
        ERR_NON_RESSETTABLE_FAULT = 30,
        ERR_EXTAXIS_CONFIG_FAILURE = 33,//外部轴未处于零位，导程、分辨率设置失败
        ERR_WORKPIECE_NUM = 34,
        ERR_FILENAME_TOO_LONG = 36,
        ERR_TOOL_NUM = 37,
        ERR_STRANGE_POSE = 38,
        ERR_EXTAXIS_NOT_HOMING = 41,//外部轴未回零
        ERR_EXTAXIS_NOT_ACTIVING = 45,//外部轴未激活
        ERR_EXTAXIS_NOT_CALIB = 46,//同步功能需要标定外部轴
        ERR_EXTAXIS_SERVO_CONFIG_FAIL = 47,//外部驱动器信息配置失败
        ERR_EXTAXIS_SERVO_CONFIG_OVER = 48,//外部轴驱动器信息获取超时
        ERR_EXTAXIS_NOT_STEP_OPERATE = 52,//同步功能不能使用单步操作
        ERR_NOT_ADD_CMD_QUEUE = 64,
        ERR_CIRCLE_SPIRAL_MIDDLE_POINT1 = 66,
        ERR_CIRCLE_SPIRAL_MIDDLE_POINT2 = 67,
        ERR_CIRCLE_SPIRAL_MIDDLE_POINT3 = 68,
        ERR_MOVEC_MIDDLE_POINT = 69,
        ERR_MOVEC_TARGET_POINT = 70,
        ERR_GRIPPER_MOTION = 73,
        ERR_LINE_POINT = 74,
        ERR_CHANNEL_FAULT = 75,
        ERR_WAIT_TIMEOUT = 76,
        ERR_TPD_CMD_POINT = 82,
        ERR_TPD_CMD_TOOL = 83,
        ERR_SPLINE_POINT = 94,
        ERR_SPIRAL_START_POINT = 108,
        ERR_TARGET_POSE_CANNOT_REACHED = 112,
        ERR_POINTTABLE_NOTFOUND = 130,
        ERR_TEACHINGPOINTNOTFOUND = 143,  //示教点位信息不存在
        ERR_LUAFILENITFOUND = 144         //LUA文件不存在
    }


    internal class RobotTypes
    {

    }
}
